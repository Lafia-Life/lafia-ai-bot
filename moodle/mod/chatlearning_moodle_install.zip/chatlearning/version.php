<?php
// SPDX-License-Identifier: Apache-2.0

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_chatlearning';
$plugin->version = 2026031101;
$plugin->requires = 2022041900;
$plugin->release = '0.2.1';
$plugin->maturity = MATURITY_ALPHA;
